package Interfaces;

public interface Updateable {
    public void update();
}
