package Interfaces;

import Entity.Entity;

public interface Useable {
    public void use(Entity entity);
}
