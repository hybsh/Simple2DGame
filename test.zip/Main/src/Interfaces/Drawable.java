package Interfaces;

import java.awt.*;

public interface Drawable {
    public void draw(Graphics2D g2);
}
